package com.example.zimamchanifushs_presidenku

class Datagambar (val gambar: Int, val nama: String,val priode: String)

